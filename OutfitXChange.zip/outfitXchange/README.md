# OutfitXchange
An Android application for high-fashion and luxury item rentals.
