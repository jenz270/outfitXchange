package com.jienihou.outfitxchange

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView


/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [home_screen.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [home_screen.newInstance] factory method to
 * create an instance of this fragment.
 */
class HomeScreen : Fragment() {
    private lateinit var bottomNavigationView: BottomNavigationView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        activity?.actionBar?.show()
        val view = inflater.inflate(R.layout.fragment_home_screen, container, false)

        bottomNavigationView = R.id.bottom_navigation as BottomNavigationView
        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.action_home -> Toast.makeText(
                    this.context,
                    "Home",
                    Toast.LENGTH_SHORT
                ).show()
                R.id.action_messages -> Toast.makeText(
                    this.context,
                    "Messages",
                    Toast.LENGTH_SHORT
                ).show()
                R.id.action_add -> Toast.makeText(
                    this.context,
                    "Add item",
                    Toast.LENGTH_SHORT
                ).show()
                R.id.action_favorites -> Toast.makeText(
                    this.context,
                    "Favourites",
                    Toast.LENGTH_SHORT
                ).show()
                R.id.action_account -> Toast.makeText(
                    this.context,
                    "Profile",
                    Toast.LENGTH_SHORT
                ).show()
            }
            true
        }
        return view
    }
}
